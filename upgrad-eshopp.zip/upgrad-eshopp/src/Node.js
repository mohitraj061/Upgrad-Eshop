const cors = require("cors");
app.use(cors()); // Allow all origins

// OR, allow only localhost:3000
app.use(cors({ origin: "http://localhost:3000" }));
