import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar'; // ✅ Correct Path
import Login from './components/Login';   // ✅ Correct Path
import Signup from './components/Signup'; // ✅ Correct Path
import Products from './components/Product'; // ✅ Correct Path

const App = () => {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Products />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
      </Routes>
    </Router>
  );
};

export default App;
