import React, { useState } from "react";
import axios from "axios";
import "./signup.css"; // Ensure to create and import this CSS file

const Signup = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleSignup = async (event) => {
    event.preventDefault();
    setError(null);
    setSuccess(null);

    if (!firstName || !lastName || !email || !password || !confirmPassword || !contactNumber) {
      setError("All fields are required.");
      return;
    }

    if (!email.includes("@")) {
      setError("Invalid email format.");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    if (!/^\d{10}$/.test(contactNumber)) {
      setError("Contact number must be exactly 10 digits.");
      return;
    }

    const data = {
      firstName,
      lastName,
      email,
      password,
      contactNumber,
    };

    console.log("Sending Signup Data:", data);

    try {
      const response = await axios.post(
        "https://dev-project-ecommerce.upgrad.dev/api/auth/signup",
        data,
        { headers: { "Content-Type": "application/json" } }
      );

      setSuccess("Signup successful! Please log in.");
      console.log("Signup Successful!", response.data);
    } catch (error) {
      setError(error.response?.data?.message || "Signup failed. Please try again.");
    }
  };

  return (
    <div className="signup-container">
      <div className="signup-box">
        <div className="lock-icon">🔒</div> {/* Lock icon on top */}
        <h2>Sign up</h2>

        {error && <p className="error">{error}</p>}
        {success && <p className="success">{success}</p>}

        <form onSubmit={handleSignup}>
          <input type="text" placeholder="First Name *" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
          <input type="text" placeholder="Last Name *" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
          <input type="email" placeholder="Email Address *" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <input type="password" placeholder="Password *" value={password} onChange={(e) => setPassword(e.target.value)} required />
          <input type="password" placeholder="Confirm Password *" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
          <input type="text" placeholder="Contact Number *" value={contactNumber} onChange={(e) => setContactNumber(e.target.value)} required />
          <button type="submit">SIGN UP</button>
        </form>

        <p className="login-link">
          Already have an account? <a href="/login">Sign in</a>
        </p>
      </div>
    </div>
  );
};

export default Signup;
