import React from 'react';
import { AppBar, Toolbar, Typography, Button, TextField } from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Navbar = () => {
  const navigate = useNavigate();

  const handleSearch = async (event) => {
    if (event.key === 'Enter') {
      const query = event.target.value;
      try {
        const response = await axios.get(
          `https://dev-project-ecommerce.upgrad.dev/api/products?search=${query}`
        );
        console.log(response.data);
      } catch (error) {
        console.error('Search error:', error);
      }
    }
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: '#3f51b5', padding: 1 }}>
      <Toolbar>
        <ShoppingCartIcon sx={{ fontSize: 30, marginRight: 1 }} />
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          upGrad E-Shop
        </Typography>
        <TextField
          variant="outlined"
          placeholder="Search..."
          size="small"
          sx={{ backgroundColor: 'white', borderRadius: 1 }}
          onKeyDown={handleSearch}
        />
        <Button color="inherit" component={Link} to="/">
          Home
        </Button>
        <Button color="inherit" component={Link} to="/signup">
          Add Product
        </Button>
        <Button
          variant="contained"
          color="error"
          component={Link}
          to="/login"
          sx={{ marginLeft: 2 }}
        >
          LOGIN
        </Button>
      </Toolbar>
    </AppBar>
  );
};
const Login = () => {
  return (
    <>
      <Navbar />
      {/* Your existing Login form code */}
    </>
  );
};
export default Navbar;
