import React, { useState } from "react";
import { TextField, Button, Typography, Container, Box } from "@mui/material";
import LockIcon from "@mui/icons-material/Lock";
import axios from "axios";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    try {
      const API_URL = "https://dev-project-ecommerce.upgrad.dev/api/auth/signin";

      const response = await axios.post(
        API_URL,
        { email, password },
        { headers: { "Content-Type": "application/json" } }
      );

      alert("Login successful!");
    } catch (error) {
      console.error("Login error:", error.response?.data || error);
      alert("Login failed! Please check your credentials.");
    }
  };

  return (
    <Container maxWidth="xs">
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          mt: 8,
          p: 3,
          borderRadius: 2,
          boxShadow: 3,
          bgcolor: "white",
        }}
      >
        <LockIcon sx={{ fontSize: 50, color: "red", mb: 1 }} />
        <Typography variant="h5" sx={{ mb: 2 }}>
          Sign in
        </Typography>

        <TextField
          fullWidth
          label="Email Address *"
          type="email"
          variant="outlined"
          margin="normal"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <TextField
          fullWidth
          label="Password *"
          type="password"
          variant="outlined"
          margin="normal"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <Button
          fullWidth
          variant="contained"
          sx={{ mt: 2, bgcolor: "#3F51B5" }}
          onClick={handleLogin}
        >
          SIGN IN
        </Button>

        <Typography variant="body2" sx={{ mt: 2 }}>
          Don't have an account?{" "}
          <a href="/signup" style={{ color: "#3F51B5", textDecoration: "none" }}>
            Sign Up
          </a>
        </Typography>
      </Box>

      <Typography variant="body2" sx={{ textAlign: "center", mt: 4, color: "gray" }}>
        Copyright © <a href="https://upgrad.com" style={{ color: "#3F51B5", textDecoration: "none" }}>upGrad</a> 2021.
      </Typography>
    </Container>
  );
};

export default Login;
