import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Box,
} from "@mui/material";

const products = [
  {
    id: 1,
    name: "Shoes",
    price: 1000,
    description:
      "wndr-13 sports shoes for men | Latest Stylish Casual sport shoes for men | running shoes for boys | Lace up Lightweight grey shoes for running, walking, gym, trekking, hiking & party",
    image: "https://via.placeholder.com/300", // Replace with actual image URL
  },
];

const Products = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  // Check if user is logged in
  useEffect(() => {
    const loggedInUser = localStorage.getItem("user"); // Example authentication check
    if (!loggedInUser) {
      navigate("/login"); // Redirect to login if not logged in
    } else {
      setUser(JSON.parse(loggedInUser)); // Store user details if logged in
    }
  }, [navigate]);

  return (
    <Box sx={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: 2, mt: 3 }}>
      {products.map((product) => (
        <Card key={product.id} sx={{ maxWidth: 345 }}>
          <CardMedia component="img" height="200" image={product.image} alt={product.name} />
          <CardContent>
            <Typography variant="h6">{product.name}</Typography>
            <Typography variant="h6" color="primary">₹ {product.price}</Typography>
            <Typography variant="body2" color="text.secondary">
              {product.description}
            </Typography>
            <Button variant="contained" color="primary" fullWidth sx={{ mt: 2 }}>
              BUY
            </Button>
          </CardContent>
        </Card>
      ))}
    </Box>
  );
};

export default Products;
